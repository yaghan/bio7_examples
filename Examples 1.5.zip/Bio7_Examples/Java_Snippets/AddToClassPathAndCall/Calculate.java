/*Use together with CalculatePlus and Snippet1_Compiler!*/
public void ecomain() {

	System.out.println("Random Number: "+ (int)(Math.random()*100));

}