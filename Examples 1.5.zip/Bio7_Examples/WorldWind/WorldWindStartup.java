/*
Simple startup for a dragged file!
*/

import com.eco.bio7.worldwind.*;


public void setup(){
	Work.openPerspective("com.eco.bio7.WorldWind.3dglobe");
	WorldWindView.setFullscreen();
}

public void setup(GL gl,GLU glu,GLUT glut){

}
public void ecomain(GL gl,GLU glu,GLUT glut){
	
	

}
