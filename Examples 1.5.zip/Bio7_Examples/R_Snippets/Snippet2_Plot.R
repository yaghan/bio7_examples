#Adjust size in BeanShell Console with "RServe.setPlotInch(10,10)."
#Plot to ImageJ(Windows)with RServe.setPdf(false).

x<-c(2,3,4,5,6,10);
y<-c(3,4,5,3,4,10);
#Mark the following lines with the "Set Plotmarker" action in the context menu !
plot(x,y,main="plot")



	
       
  