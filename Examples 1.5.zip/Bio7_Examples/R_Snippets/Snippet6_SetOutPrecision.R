#RScript - please enter your code here!

#By default display shows only 5 decimal places. Here we change this!
options(digits=10) 
Tab1