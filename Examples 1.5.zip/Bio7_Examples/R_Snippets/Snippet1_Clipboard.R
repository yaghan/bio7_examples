#Read values from the clipboard after selection and
#copy from a spreadsheet(Excel,OpenOffice,Gnumeric) to Bio7-R in a dataframe.

try(x<-read.delim("clipboard"))

