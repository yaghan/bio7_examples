#This example demonstrates how to call an executeable with R!

try(shell.exec("regedit"))#Call an executable in R!
#or: try(shell("regedit"))