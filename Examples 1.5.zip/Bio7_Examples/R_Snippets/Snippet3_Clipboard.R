#Select values in OpenOffice or Excel,copy them and then
#interpret this file!

try(from_clip<-scan("clipboard"))