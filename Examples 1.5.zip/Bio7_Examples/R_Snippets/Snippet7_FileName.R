#This example shows how to open a file dialog with R!

fileName<-choose.files();
print(fileName)