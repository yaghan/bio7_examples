#A simple RScript producing random numbers !


result<-runif(1:100);
