#RScript - please enter your code here !
#These variables have to be present!
imageSizeY<-1000
imageSizeX<-1000
imageMatrix<-as.raw(runif(1000000)*255)

