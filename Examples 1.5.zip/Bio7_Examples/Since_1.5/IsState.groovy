/*
New API method to detect a state by name!
*/
boolean st=Field.isState(0, 0, "State");
System.out.println(st);