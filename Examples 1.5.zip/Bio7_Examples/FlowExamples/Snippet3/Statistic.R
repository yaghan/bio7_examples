#RScript - please enter your code here !
summary_one<-summary(StateOne_0)
summary_two<-summary(StateTwo_0)