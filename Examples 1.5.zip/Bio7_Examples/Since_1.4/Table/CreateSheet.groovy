/*
This Snippet creates a new Sheet!
*/
Bio7Grid.createSheet(50,100,"SpreadCustom");//With colsize 50 and rowsize 100!