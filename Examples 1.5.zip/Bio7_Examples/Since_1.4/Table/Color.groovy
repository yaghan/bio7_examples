/*
This Snippet colours one cell in the current sheet!
*/
Bio7Grid.createSheet(10,10,"Color");
Bio7Grid.setColor(5,5,255,0,0);// Starts with 0 !