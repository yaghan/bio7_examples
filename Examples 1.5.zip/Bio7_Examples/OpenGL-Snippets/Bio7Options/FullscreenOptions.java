/*
Fullscreen options can be set programmatically.
Please invoke the setup before you trigger the fullscreen option!

*/


public void setup(GL gl,GLU glu,GLUT glut){
	
/*Please select only available screen settings!*/
SpatialUtil.setFullscreenOptions(1024,768,60,16);

}
public void ecomain(GL gl,GLU glu,GLUT glut){
// Please enter your Java OpenGL code here
}