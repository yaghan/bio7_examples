/*
You can resize or locate the splitscreen with this method dynamically!
*/

public void setup(GL gl,GLU glu,GLUT glut){
// Please enter your Java OpenGL setup code here

}
public void ecomain(GL gl,GLU glu,GLUT glut){
	
SpatialUtil.setSplitScreenSizeLocation(0,500,100,100);


}