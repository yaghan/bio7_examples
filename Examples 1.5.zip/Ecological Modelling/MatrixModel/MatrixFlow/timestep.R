#RScript - please enter your code here !
n1<-L%*%n0
n0<-n1